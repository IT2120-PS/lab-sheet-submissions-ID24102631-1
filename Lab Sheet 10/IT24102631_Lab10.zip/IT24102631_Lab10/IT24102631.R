setwd("C:\\Users\\Nethmi Balasooriya\\Desktop\\IT24102631_Lab10")

#Q1

#Null hypothesis : Customers chooses all snack types(A,B,C,D) with equal probability.
#pA=pB=pC=pD=0.25

#Alternative Hypothesis: Customers do not choose all snack types with equal probability.

#Q2
observed_counts <- c(120, 95, 85, 100)

chisq.test(x = observed_counts)

#Q3
#the p-value is not less than 0.05,we do not reject the null hypothesis.
#There is not enough statistical evidence to reject the vending machine 
#Owner's claim that customer choose the four snack types with equal probability.